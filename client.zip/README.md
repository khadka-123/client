#Twitter sentiment analysis

WEBPAGES:
**create seperate folders for the webpages
-Dashboard-ez

  1. Election prediction-ez
  1.1. Election Alalysis-kh
    
  2. Influential leader rankings-de

Note: webpages dir is src/pages/

